/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Excepciones.ExcepcionArchivo;
import Persistencia.ArchivoObjetoCaso;
import Persistencia.ArchivoObjetoDetective;
import Persistencia.ICasoDao;
import Persistencia.IDetectiveDao;
import java.util.List;

/**
 *
 * @author carlo
 */
public class ListaCaso implements ICasoDao {
    private ICasoDao registroCaso;

    public ListaCaso() {
        this.registroCaso = new ArchivoObjetoCaso();
    }
    
    

    @Override
    public void insertarPublicacion(Caso p) throws ExcepcionArchivo {

        this.registroCaso.insertarPublicacion(p);

    }

    @Override
    public List<Caso> leerPublicaciones() throws ExcepcionArchivo {

        return this.registroCaso.leerPublicaciones();

    }

    @Override
    public Caso buscarPublicacion(Caso p) throws ExcepcionArchivo {

        return this.registroCaso.buscarPublicacion(p);

    }

    @Override
    public Caso eliminarPublicacion(Caso p) throws ExcepcionArchivo {

        return this.registroCaso.eliminarPublicacion(p);

    }

}
