/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Excepciones.ExcepcionArchivo;
import Persistencia.ArchivoObjetoDetective;
import Persistencia.IDetectiveDao;
import java.util.List;

/**
 *
 * @author carlo
 */
public class ListaDetective implements IDetectiveDao {
    private IDetectiveDao registroDetective;

    public ListaDetective() {
        this.registroDetective = new ArchivoObjetoDetective();
    }
    
    

    @Override
    public void insertarPublicacion(Detective p) throws ExcepcionArchivo {

        this.registroDetective.insertarPublicacion(p);

    }

    @Override
    public List<Detective> leerPublicaciones() throws ExcepcionArchivo {

        return this.registroDetective.leerPublicaciones();

    }

    @Override
    public Detective buscarPublicacion(Detective p) throws ExcepcionArchivo {

        return this.registroDetective.buscarPublicacion(p);

    }

    @Override
    public Detective eliminarPublicacion(Detective p) throws ExcepcionArchivo {

        return this.registroDetective.eliminarPublicacion(p);

    }

    @Override
    public List<Detective> filtrar(int idbn) throws ExcepcionArchivo {
        return this.registroDetective.filtrar(idbn);

    }

}
