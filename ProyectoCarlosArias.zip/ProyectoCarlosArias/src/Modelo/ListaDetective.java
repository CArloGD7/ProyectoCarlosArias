/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Excepciones.ExcepcionArchivo;
import Persistencia.ArchivoObjetoDetective;
import Persistencia.IDetectiveDao;
import java.util.List;

/**
 *
 * @author carlo
 */
public class ListaDetective implements IDetectiveDao {
    private IDetectiveDao registroDetective;

    public ListaDetective() {
        this.registroDetective = new ArchivoObjetoDetective();
    }
    
    

    @Override
    public void insertarDetective(Detective p) throws ExcepcionArchivo {

        this.registroDetective.insertarDetective(p);

    }

    @Override
    public List<Detective> leerDetective() throws ExcepcionArchivo {

        return this.registroDetective.leerDetective();

    }

    @Override
    public Detective buscarDetective(Detective p) throws ExcepcionArchivo {

        return this.registroDetective.buscarDetective(p);

    }

    @Override
    public Detective eliminarDetective(Detective p) throws ExcepcionArchivo {

        return this.registroDetective.eliminarDetective(p);

    }



}
