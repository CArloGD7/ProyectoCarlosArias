/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Excepciones.ExcepcionArchivo;
import Persistencia.ArchivoObjetoSospechoso;
import Persistencia.ISospechosoDao;
import java.util.List;

/**
 *
 * @author carlo
 */
public class ListaSospechoso implements ISospechosoDao {
    private ISospechosoDao registroSospechoso;

    public ListaSospechoso() {
        this.registroSospechoso = new ArchivoObjetoSospechoso();
    }
    
    

    @Override
    public void insertarSospechoso(Sospechoso p) throws ExcepcionArchivo {

        this.registroSospechoso.insertarSospechoso(p);

    }

    @Override
    public List<Sospechoso> leerSospechoso() throws ExcepcionArchivo {

        return this.registroSospechoso.leerSospechoso();

    }

    @Override
    public Sospechoso buscarSospechoso(Sospechoso p) throws ExcepcionArchivo {

        return this.registroSospechoso.buscarSospechoso(p);

    }

    @Override
    public Sospechoso eliminarSospechoso(Sospechoso p) throws ExcepcionArchivo {

        return this.registroSospechoso.eliminarSospechoso(p);

    }

}
