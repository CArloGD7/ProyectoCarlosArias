package Modelo;

import java.util.ArrayList;

public class Oficina {
    private ArrayList<Detective> detectives;

    public Oficina() {
        detectives= new ArrayList<Detective>();
    }
    
    public void agregar(Detective a){
        detectives.add(a);
    }
    
}
