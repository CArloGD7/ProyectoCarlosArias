/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.io.Serializable;

/**
 *
 * @author carlo
 */
public abstract class Caso implements Serializable{
    private int numero;
    private String descripcion;
    private String codigo;
    private int idDetective;
    private String nombreClave;

    public Caso(int numero, String descripcion, String codigo, int idDetective, String nombreClave) {
        this.numero = numero;
        this.descripcion = descripcion;
        this.codigo = codigo;
        this.idDetective = idDetective;
        this.nombreClave = nombreClave;
    }

    public Caso(int numero) {
        this.numero = numero;
    }
    

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public int getIdDetective() {
        return idDetective;
    }

    public void setIdDetective(int idDetective) {
        this.idDetective = idDetective;
    }

    public String getNombreClave() {
        return nombreClave;
    }

    public void setNombreClave(String nombreClave) {
        this.nombreClave = nombreClave;
    }
    
    public abstract String getDataFileFormat();
    
}
