package Modelo;

public class Cibercrimen extends Caso {
    private String Tipo;

    public Cibercrimen(int numero, String descripcion, String codigo, int idDetective, String nombreClave, String Tipo) {
        super(numero, descripcion, codigo, idDetective, nombreClave);
        this.Tipo = Tipo;
    }

    public Cibercrimen(int numero) {
        super(numero);
    }
    

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    @Override
    public String getDataFileFormat() {
        return "Cibercrimen;" + this.getNumero() + ";" + this.getDescripcion() + ";" + this.getCodigo() + ";" + this.getIdDetective() + ";" + this.getNombreClave() + ";" + this.getTipo()+";" + "";
    }
    
    
    
}
