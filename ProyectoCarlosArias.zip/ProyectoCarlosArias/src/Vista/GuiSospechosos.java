/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;

import Excepciones.ExcepcionArchivo;
import Modelo.ListaDetective;
import Modelo.ListaSospechoso;
import Modelo.Sospechoso;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author carlo
 */
public class GuiSospechosos extends javax.swing.JFrame {

    DefaultTableModel Td = new DefaultTableModel();
    ListaSospechoso modelo;
    List<Sospechoso> Lista;

    public GuiSospechosos() {
        initComponents();
        this.setLocationRelativeTo(null);
        String[] titulo;
        titulo = new String[]{"ID", "NOMBRE", "ALIAS", "EDAD", "N"
            + "N° VIVIENDA", "LOCALIDAD", "CIUDAD", "DEPARTAMENTO", "PAIS", "DESCRIPCION"};
        Td.setColumnIdentifiers(titulo);
        TblDec.setModel(Td);
        this.modelo = new ListaSospechoso();
        actualizarTabla();
        this.setLocationRelativeTo(this);

    }

    public void actualizarTabla() {
        try {
            this.Lista = this.modelo.leerSospechoso();
        } catch (ExcepcionArchivo ex) {
            Logger.getLogger(GuiDetective.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.Td.setNumRows(0);
        for (Sospechoso p : this.Lista) {
            String datos[] = {String.valueOf(p.getId()), p.getNombre(), p.getAlias(), String.valueOf(p.getEdad()), p.getNvivienda(), p.getLocalidad(), p.getCiudad(), p.getDepartamento(), p.getPais(), p.getDescripcion()};
            this.Td.addRow(datos);

        }
    }

    private void limpiarCampos() {

        this.txtId.setText(null);
        this.txtNombre.setText(null);
        this.txtAlias.setText(null);
        this.txtEdad.setText(null);
        this.txtVivienda.setText(null);
        this.txtLocalidad.setText(null);
        this.txtCiudad.setText(null);
        this.txtDepa.setText(null);
        this.txtPais.setText(null);
        this.txtDes.setText(null);

    }

    private void asginarCampos() {
        String id = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 0);
        String nom = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 1);
        String ali = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 2);
        String edad = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 3);
        String nvi = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 4);
        String local = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 5);
        String ciud = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 6);
        String depa = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 7);
        String pais = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 8);
        String des = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 9);

        this.txtId.setText(id);
        this.txtNombre.setText(nom);
        this.txtAlias.setText(ali);
        this.txtEdad.setText(edad);
        this.txtVivienda.setText(nvi);
        this.txtLocalidad.setText(local);
        this.txtCiudad.setText(ciud);
        this.txtDepa.setText(depa);
        this.txtPais.setText(pais);
        this.txtDes.setText(des);

    }

    private void guardarDatos() {
        try {
            Sospechoso c = this.leerDatos();
            this.modelo.insertarSospechoso(c);

        } catch (ExcepcionArchivo e) {
            JOptionPane.showMessageDialog(null, "Error", "Eror", JOptionPane.WARNING_MESSAGE);

        }

    }

    private Sospechoso leerDatos() {
        int id = Integer.valueOf(this.txtId.getText());
        String nombre = this.txtNombre.getText();
        String alias = this.txtAlias.getText();
        int edad = Integer.valueOf(this.txtEdad.getText());
        String nvivienda = this.txtVivienda.getText();
        String localidad = this.txtLocalidad.getText();
        String ciudad = this.txtCiudad.getText();
        String departamento = this.txtDepa.getText();
        String pais = this.txtPais.getText();
        String descrip = this.txtDes.getText();

        return new Sospechoso(id, nombre, alias, edad, nvivienda, localidad, ciudad, departamento, pais, descrip);
    }

    private void eliminarDato() {
        String idEliminado = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 0);
        int id = Integer.valueOf(idEliminado);
        try {
            Sospechoso eliminado = this.modelo.eliminarSospechoso(new Sospechoso(id));
            this.actualizarTabla();
        } catch (ExcepcionArchivo e) {

        }
    }

    void GUARDAR() {
        Td.addRow(new Object[]{txtId.getText(), txtNombre.getText(), txtAlias.getText(), txtVivienda.getText(), txtVivienda.getText()});
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        FONDO = new javax.swing.JPanel();
        txtId = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtAlias = new javax.swing.JTextField();
        txtVivienda = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        TblDec = new javax.swing.JTable();
        txtEdad = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtLocalidad = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtCiudad = new javax.swing.JTextField();
        txtDepa = new javax.swing.JTextField();
        txtPais = new javax.swing.JTextField();
        txtDes = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Detective");

        FONDO.setBackground(new java.awt.Color(204, 204, 204));
        FONDO.setMaximumSize(new java.awt.Dimension(720, 400));
        FONDO.setRequestFocusEnabled(false);
        FONDO.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });
        txtId.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtIdKeyTyped(evt);
            }
        });
        FONDO.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 150, 160, -1));

        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombreKeyTyped(evt);
            }
        });
        FONDO.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 180, 160, -1));

        txtAlias.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtAliasKeyTyped(evt);
            }
        });
        FONDO.add(txtAlias, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 210, 160, -1));

        txtVivienda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtViviendaActionPerformed(evt);
            }
        });
        FONDO.add(txtVivienda, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 310, 160, -1));

        jButton1.setText("Agregar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        FONDO.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 510, -1, -1));

        jButton2.setText("Editar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        FONDO.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 510, -1, -1));

        jButton3.setText("Eliminar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        FONDO.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 510, -1, -1));

        jLabel7.setFont(new java.awt.Font("Roboto Black", 1, 36)); // NOI18N
        jLabel7.setText("CasoCerrado");
        FONDO.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, -1, -1));

        jLabel1.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel1.setText("ID:");
        FONDO.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 150, -1, -1));

        jLabel2.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel2.setText("NOMBRE:");
        FONDO.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 180, -1, 20));

        jLabel3.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel3.setText("ALIAS:");
        FONDO.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, -1, -1));

        jLabel4.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel4.setText("EDAD:");
        FONDO.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 240, -1, -1));

        jLabel5.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel5.setText("N° VIVIENDA");
        FONDO.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 310, -1, 20));

        jButton4.setFont(new java.awt.Font("Roboto Black", 1, 12)); // NOI18N
        jButton4.setText("<");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        FONDO.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 550, 50, 30));

        TblDec.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TblDec.setEditingColumn(0);
        TblDec.setEditingRow(0);
        jScrollPane2.setViewportView(TblDec);

        FONDO.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 70, 680, 470));

        txtEdad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEdadActionPerformed(evt);
            }
        });
        txtEdad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtEdadKeyTyped(evt);
            }
        });
        FONDO.add(txtEdad, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 240, 160, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/SOSPECHOSO1.png"))); // NOI18N
        FONDO.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 30, -1, -1));

        jLabel6.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel6.setText("LOCALIDAD:");
        FONDO.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 340, -1, -1));

        jLabel9.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel9.setText("CIUDAD:");
        FONDO.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 370, -1, -1));

        jLabel10.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel10.setText("DEPARTAMENTO:");
        FONDO.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 400, -1, -1));

        jLabel11.setFont(new java.awt.Font("Roboto Black", 0, 14)); // NOI18N
        jLabel11.setText("PAIS:");
        FONDO.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 430, -1, -1));

        txtLocalidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLocalidadActionPerformed(evt);
            }
        });
        FONDO.add(txtLocalidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 340, 160, -1));

        jLabel12.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel12.setText("DESCRIPCION FISICA:");
        FONDO.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, -1, 20));

        txtCiudad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCiudadKeyTyped(evt);
            }
        });
        FONDO.add(txtCiudad, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 370, 160, -1));

        txtDepa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDepaKeyTyped(evt);
            }
        });
        FONDO.add(txtDepa, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 400, 160, -1));

        txtPais.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtPaisKeyTyped(evt);
            }
        });
        FONDO.add(txtPais, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 430, 160, -1));

        txtDes.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDesKeyTyped(evt);
            }
        });
        FONDO.add(txtDes, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 460, 160, -1));

        jLabel13.setFont(new java.awt.Font("Roboto Light", 1, 18)); // NOI18N
        jLabel13.setText("DIRECCION");
        FONDO.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 280, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(FONDO, javax.swing.GroupLayout.PREFERRED_SIZE, 979, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(FONDO, javax.swing.GroupLayout.DEFAULT_SIZE, 604, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtIdKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdKeyTyped
        // TODO add your handling code here:
        char validar = evt.getKeyChar();

        if (Character.isLetter(validar)) {
            getToolkit().beep();
            evt.consume();
        }

    }//GEN-LAST:event_txtIdKeyTyped

    private void txtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyTyped
        char validar = evt.getKeyChar();

        if (Character.isDigit(validar)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txtNombreKeyTyped

    private void txtAliasKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtAliasKeyTyped

        char validar = evt.getKeyChar();

        if (Character.isDigit(validar)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txtAliasKeyTyped

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        GuiCaso b = new GuiCaso();
        b.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.guardarDatos();
        this.actualizarTabla();
        limpiarCampos();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtViviendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtViviendaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtViviendaActionPerformed

    private void txtLocalidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLocalidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtLocalidadActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        asginarCampos();
        eliminarDato();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        eliminarDato();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txtEdadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEdadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEdadActionPerformed

    private void txtEdadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtEdadKeyTyped
        char validar = evt.getKeyChar();

        if (Character.isLetter(validar)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txtEdadKeyTyped

    private void txtCiudadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCiudadKeyTyped
        char validar = evt.getKeyChar();

        if (Character.isDigit(validar)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txtCiudadKeyTyped

    private void txtDepaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDepaKeyTyped
        char validar = evt.getKeyChar();

        if (Character.isDigit(validar)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txtDepaKeyTyped

    private void txtPaisKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPaisKeyTyped
        char validar = evt.getKeyChar();

        if (Character.isDigit(validar)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txtPaisKeyTyped

    private void txtDesKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDesKeyTyped
        char validar = evt.getKeyChar();

        if (Character.isDigit(validar)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txtDesKeyTyped

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel FONDO;
    private javax.swing.JTable TblDec;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtAlias;
    private javax.swing.JTextField txtCiudad;
    private javax.swing.JTextField txtDepa;
    private javax.swing.JTextField txtDes;
    private javax.swing.JTextField txtEdad;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtLocalidad;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPais;
    private javax.swing.JTextField txtVivienda;
    // End of variables declaration//GEN-END:variables
}
