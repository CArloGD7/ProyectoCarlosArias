package Persistencia;

import Excepciones.ExcepcionArchivo;
import Modelo.Detective;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ArchivoObjetoDetective implements IDetectiveDao {

    private File archivo;
    private FileInputStream modoLectura;
    private FileOutputStream modoEscritura;

    public ArchivoObjetoDetective() {
        this("Detectives.bin");
    }

    public ArchivoObjetoDetective(String path) {
        this.archivo = new File(path);
    }

    public File getArchivo() {
        return archivo;
    }

    public void setArchivo(File archivo) {
        this.archivo = archivo;
    }

    public FileInputStream getModoLectura() {
        return modoLectura;
    }

    public void setModoLectura(FileInputStream modoLectura) {
        this.modoLectura = modoLectura;
    }

    public FileOutputStream getModoEscritura() {
        return modoEscritura;
    }

    public void setModoEscritura(FileOutputStream modoEscritura) {
        this.modoEscritura = modoEscritura;
    }

    
    private void guardarArchivo(List<Detective> lista) throws ExcepcionArchivo, FileNotFoundException, IOException {
        try {
            this.modoEscritura = new FileOutputStream(this.archivo);
            ObjectOutputStream oos = new ObjectOutputStream(this.modoEscritura);
            oos.writeObject(lista);
            oos.close();

        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivo("Erro al abrir archivo de objetos, no existe");
        } catch (SecurityException e) {
            throw new ExcepcionArchivo("No tiene acceso para el archivo en modo escritura");
        } catch (NullPointerException e) {
            throw new ExcepcionArchivo("EL manejador de archivo en escritura en Null");
        } catch (IOException e) {
            throw new ExcepcionArchivo("Error al escribir en el archivo");
        }

    }

    private List<Detective> leerArchivo() throws ExcepcionArchivo {
        
        ObjectInputStream ois = null;
        if(!this.archivo.exists()){
            return new ArrayList<Detective>();
        }
        
        try {
            this.modoLectura = new FileInputStream(this.archivo);
            ois = new ObjectInputStream(this.modoLectura);
            List<Detective> lista = (List<Detective>)ois.readObject();
            ois.close();
            return lista;

        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivo("Erro al abrir archivo de objetos en modo lectura , no existe");
        } catch (SecurityException e) {
            throw new ExcepcionArchivo("No tiene acceso para el archivo en modo lectura");
        } catch (StreamCorruptedException e) {
            throw new ExcepcionArchivo("Error con el flujo de datos de cabecera del objeto");
        } catch (NullPointerException e) {
            throw new ExcepcionArchivo("EL manejador de archivo en lectura en Null");
        } catch (IOException e) {
            throw new ExcepcionArchivo("Error al leer en el archivo");
        }
        catch(ClassNotFoundException e){
            throw new ExcepcionArchivo("Error, el objeto leido del archivo no tiene clase definida");
        }

    }
    @Override
    public void insertarPublicacion(Detective p) throws ExcepcionArchivo {
        List<Detective> lista = this.leerArchivo();
        lista.add(p);
        try {
            this.guardarArchivo(lista);
        } catch (IOException ex) {
            Logger.getLogger(ArchivoObjetoDetective.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public List<Detective> leerPublicaciones() throws ExcepcionArchivo {
            return this.leerArchivo();
    }

    
    
    @Override
    public Detective buscarPublicacion(Detective p) throws ExcepcionArchivo {
          List<Detective> lista = this.leerArchivo();
          for(Detective b: lista){
              if(b.getId()==(p.getId())){
                  return b;
              }
          }
          return null;    }

    @Override
    public Detective eliminarPublicacion(Detective p) throws ExcepcionArchivo {
        List<Detective> lista = this.leerArchivo();
        Iterator<Detective>i = lista.iterator();
        Detective eliminado=null;
        while(i.hasNext()){
            Detective leido = i.next();
            if(leido.getId()==(p.getId())){
                eliminado = leido;
                i.remove();
            }
        }
        try {
            this.guardarArchivo(lista);
        } catch (IOException ex) {
            Logger.getLogger(ArchivoObjetoDetective.class.getName()).log(Level.SEVERE, null, ex);
        }
        return eliminado;    }

    @Override
    public List<Detective> filtrar(int id) throws ExcepcionArchivo {
        List<Detective> lista = this.leerArchivo();
        List<Detective> listaFiltrada = new ArrayList();
        for(Detective a: lista){
            int idLista = a.getId();
            int idFiltrada = id;
            if(idLista==(idFiltrada)){
                listaFiltrada.add(a);
            }
            
        }
        return listaFiltrada;
    }

}
