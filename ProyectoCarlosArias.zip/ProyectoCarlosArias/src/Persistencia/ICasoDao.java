/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Persistencia;

import Excepciones.ExcepcionArchivo;
import Modelo.Caso;
import java.util.List;

/**
 *
 * @author JAIRO
 */
public interface ICasoDao {
    
    void insertarPublicacion(Caso p)throws ExcepcionArchivo;
    List<Caso> leerPublicaciones()throws ExcepcionArchivo;
    Caso buscarPublicacion(Caso p)throws ExcepcionArchivo;
    Caso eliminarPublicacion(Caso p)throws ExcepcionArchivo;
    
}
