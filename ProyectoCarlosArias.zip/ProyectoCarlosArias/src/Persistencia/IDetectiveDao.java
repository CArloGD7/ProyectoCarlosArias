/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Persistencia;

import Excepciones.ExcepcionArchivo;
import Modelo.Detective;
import java.util.List;

/**
 *
 * @author JAIRO
 */
public interface IDetectiveDao {
    
    void insertarDetective(Detective p)throws ExcepcionArchivo;
    List<Detective> leerDetective()throws ExcepcionArchivo;
    Detective buscarDetective(Detective p)throws ExcepcionArchivo;
    Detective eliminarDetective(Detective p)throws ExcepcionArchivo;
    
}
