/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Persistencia;

import Excepciones.ExcepcionArchivo;
import Modelo.Detective;
import java.util.List;

/**
 *
 * @author JAIRO
 */
public interface IDetectiveDao {
    
    void insertarPublicacion(Detective p)throws ExcepcionArchivo;
    List<Detective> leerPublicaciones()throws ExcepcionArchivo;
    Detective buscarPublicacion(Detective p)throws ExcepcionArchivo;
    Detective eliminarPublicacion(Detective p)throws ExcepcionArchivo;
    List<Detective> filtrar(int idbn) throws ExcepcionArchivo;
    
}
